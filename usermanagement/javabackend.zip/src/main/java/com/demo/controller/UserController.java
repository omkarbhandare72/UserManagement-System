package com.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

import com.demo.exception.UserNotFoundException;
import com.demo.model.User;
import com.demo.repository.UserRepository;

@RestController
@CrossOrigin("http://localhost:3000")
public class UserController {
	@Autowired
	private UserRepository userRepository;
	@PostMapping("/user")
	User newUser(@RequestBody User newUser) {
		return userRepository.save(newUser);
	}
	@GetMapping("/users")
	List<User>getAllUsers(){
	return userRepository.findAll();
}
    @GetMapping("/user/{id}")
    User getUSerById(@PathVariable Long id){
    	return userRepository.findById(id).orElseThrow(()-> new UserNotFoundException(id));
    }
    @PutMapping("/user/{id}")
    User updateUser(@RequestBody User newUser,@PathVariable Long id){
    	return userRepository.findById(id).map(user ->{
    		user.setUsername(newUser.getUsername());
    		user.setName(newUser.getName());
    		return userRepository.save(user);
    	}).orElseThrow(()->new UserNotFoundException(id));
    }
    @DeleteMapping("/user/{id}")
    String deleteUser(@PathVariable Long id) {
    	if(!userRepository.existsById(id)) {
    		throw new UserNotFoundException(id);
    	}
    	userRepository.deleteById(id);
    	return "User with "+id+"has been deleted success";
    }
    @PostMapping("/auth/register")
    User registerUser(@RequestBody User newUser) {
        return userRepository.save(newUser);
    }
    @PostMapping("/auth/login")
    public ResponseEntity<?> login(@RequestBody User loginUser) {
        User user = userRepository.findByUsername(loginUser.getUsername());
        if (user != null && user.getPassword().equals(loginUser.getPassword())) {
            return ResponseEntity.ok(user);
        }
        return ResponseEntity.status(401).body("Invalid Credentials");
    }
}
